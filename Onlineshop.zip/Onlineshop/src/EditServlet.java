

 

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        out.println("<h1>Update Employee</h1>");
        String sid=request.getParameter("id");
        
        
        Emp e=EmpDao.getEmployeeByPhone(phone);
        
        out.print("<form action='EditServlet2' method='post'>");
        out.print("<table>");
        out.print("<tr><td>First name:</td><td><input type='text' name='t1' value='"+e.getFirst_Name()+"'/></td></tr>");
        out.print("<tr><td>Name:</td><td><input type='text' name='t2' value='"+e.getLast_Name()+"'/></td></tr>");
        out.print("<tr><td>Password:</td><td><input type='text' name='t3' value='"+e.getCompany_name()+"'/></td></tr>");
        out.print("<tr><td>Email:</td><td><input type='email' name='t4' value='"+e.getEmail_Address()+"'/></td></tr>");
        out.print("<tr><td>Email:</td><td><input type='text' name='t5' value='"+e.getPhone()+"'/></td></tr>");
        
        out.print("<tr><td>Email:</td><td><input type='text' name='t6' value='"+e.getAddress()+"'/></td></tr>");
        out.print("<tr><td>Email:</td><td><input type='text' name='t7' value='"+e.getCountry()+"'/></td></tr>");
        
        out.print("<tr><td>phone no:</td><td><input type='text' name='t8' value='"+e.getApartment()+"'/></td></tr>");
        out.print("<tr><td>phone no:</td><td><input type='text' name='t9' value='"+e.getCity()+"'/></td></tr>");
        out.print("<tr><td>phone no:</td><td><input type='text' name='t10' value='"+e.getDistrict()+"'/></td></tr>");
        out.print("<tr><td>phone no:</td><td><input type='text' name='t11' value='"+e.getPostcode()+"'/></td></tr>");
        out.print("<tr><td>Country:</td><td>");
        out.print("<select name='country' style='width:150px'>");
        out.print("<option>India</option>");
        out.print("<option>USA</option>");
        out.print("<option>UK</option>");
        out.print("<option>Other</option>");
        out.print("</select>");
        out.print("</td></tr>");
        out.print("<tr><td colspan='2'><input type='submit' value='Edit &amp; Save '/></td></tr>");
        out.print("</table>");
        out.print("</form>");
        
        out.close();
    }
}
 




