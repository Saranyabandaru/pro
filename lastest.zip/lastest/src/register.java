

import java.io.*;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/register")
public class register extends HttpServlet 
{
	public void init()
	{
		System.out.println("init");
	}
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		
		
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			System.out.println("Driver is loaded"); 
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system" , "123456789");
		System.out.println("connection is created");
		
		
			
		
			PreparedStatement st=con.prepareStatement("insert into Customers values(?,?,?,?)");
			st.setString(1, a);
			st.setString(2, b);
			st.setString(3, c);
			st.setString(4, d);
			
			st.execute();
			pw.println("row inserted");
		
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		
		
		
		}
	}
	public void destroy()
	{
	System.out.println("destroy");
	}}