import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/login2")
public class login2 extends HttpServlet
 {
PreparedStatement st=null;
Connection con=null;
ResultSet rs=null;
int i=0;
public void init()
{
System.out.println("init");
try
{

}
catch(Exception ae)
{}
}

    public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        
        String a=req.getParameter("t1");
        String b=req.getParameter("t2");
        
       if(a.equals("admin") && b.equals("admin"))
	
	res.sendRedirect("adminreport.html");
else
	res.sendRedirect("index2.html");
	
}

              } 

 
